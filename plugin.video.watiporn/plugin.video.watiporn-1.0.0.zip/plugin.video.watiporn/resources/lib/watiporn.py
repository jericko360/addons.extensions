# -*- coding: utf-8 -*-
import sys
from urlparse import parse_qsl
import xbmcgui
import xbmcplugin
import urllib2
import urllib
import xbmc, xbmcaddon
import util
import htmlentitydefs
import unicodedata
import math
import time
from resources.lib.rechercheweb import * 
reload(sys)
sys.setdefaultencoding("utf-8")
COUNT = 0
barpro = 0
tempprog = 0#0.01
ADDON        = xbmcaddon.Addon()
_url = sys.argv[0]
global token
global url



WEB_INDEX = 'http://api.watiporn.com/xmbc/code.php?'
WEB_PAGE_BASE = 'http://api.watiporn.com/xmbc/'
ADDON_ID = 'plugin.video.watiporn'
params = dict(parse_qsl(sys.argv[2][1:]))
resourcelogin = xbmcplugin.getSetting(int(sys.argv[1]), 'login')
resourcepass = xbmcplugin.getSetting(int(sys.argv[1]), 'passe')




def downloadsfile(vid):
  
  if ADDON.getSetting('download_path') == '...':
   __dialog = xbmcgui.Dialog()
   dir = __dialog.browse( 3,"Downloads","files" )
   if dir:
    ADDON.setSetting('download_path',dir)
    downloadsfile(vid)
  else:
    
    response = urllib2.urlopen(WEB_INDEX + 'download=' + vid)

    if response and response.getcode() == 200:
        content = response.read()
        img = util.extract(content, '<img>', '</img>')
        fluxsd1 =  util.extract(content, '<fluxsd1>', '</fluxsd1>')
        fluxsd2 =  util.extract(content, '<fluxsd2>', '</fluxsd2>')
        fluxhd1 =  util.extract(content, '<fluxhd1>', '</fluxhd1>')
        fluxhd2 =  util.extract(content, '<fluxhd2>', '</fluxhd2>')  

        url = util.extract(content, '<url>', '</url>')
        title = util.extract(content, '<title>', '</title>')
        info = util.extract(content, '<info>', '</info>')
        
        title2 = title+'_watiporn.com.mp4'.replace(' ','_')
        response = urllib2.urlopen(url)
        content = response.read()

        dest = ADDON.getSetting('download_path') + title2

        if fluxsd1:
           fluxsd =  util.extract(content, fluxsd1, fluxsd2)
        if fluxhd1:
           fluxhd =  util.extract(content, fluxhd1, fluxhd2)

        if fluxhd:
          DownloaderClass(fluxhd.replace('\/','/').replace("pornfun.com","https://pornfun.com"),dest,title,img,info)
        else:
          DownloaderClass(fluxsd.replace('\/','/').replace("pornfun.com","https://pornfun.com"),dest,title,img,info)



    return info

def codex(video ,titre ,img):
    response = urllib2.urlopen(video)
    if response and response.getcode() == 200:
        content = response.read()
        #code1 = util.extract(content, '<code1>', '</code1>')
        #VScreateDialogOK(code1)
        #code2 = util.extract(content, '<code2>', '</code2>')
        #VScreateDialogOK(code2)
        url1 = util.extract(content, '<server1>', '</server1>')
        #VScreateDialogOK(video1)
        #video2 = util.extract(content, '<server2>', '</server2>')
        #VScreateDialogOK(video2)
        #check = util.extract(content, '<check>', '</check>')
        #VScreateDialogOK(check)
        fluxinfo = util.extract(content, '<fluxinfo>', '</fluxinfo>')

        fluxsd1 =  util.extract(content, '<fluxsd1>', '</fluxsd1>')
        fluxsd2 =  util.extract(content, '<fluxsd2>', '</fluxsd2>')
        fluxhd1 =  util.extract(content, '<fluxhd1>', '</fluxhd1>')
        fluxhd2 =  util.extract(content, '<fluxhd2>', '</fluxhd2>')  

        req = urllib2.Request(url1)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        ##req.add_header('X-Requested-With', 'XMLHttpRequest')
        req.add_header('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
        req.add_header('Accept', '*/*')
        #req.add_header('Accept-Encoding', 'gzip, deflate')
        #req.add_header('Accept-Language', 'en-US,en;q=0.8,nl;q=0.6')
        #req.add_header('Connection', 'keep-alive')
        req.add_header('Accept','text/html')
        response2 = urllib2.urlopen(req)
        if response2 and response2.getcode() == 200:
         content2 = response2.read()
         if fluxsd1:
           fluxsd =  util.extract(content2, fluxsd1, fluxsd2)
         if fluxhd1:
           fluxhd =  util.extract(content2, fluxhd1, fluxhd2)

        if fluxhd:

          util.notify(ADDON_ID, '[COLOR lime]HD[/COLOR] '+fluxinfo ,5000 ,img)
          util.playMedia(titre, img, fluxhd.replace('\/','/').replace("pornfun.com","https://pornfun.com"), 'Video')
          ADDON.setSetting('getnbvideo', COUNTNB('{0}'.format(ADDON.getSetting( 'getnbvideo'))))
        else:

          util.notify(ADDON_ID, '[COLOR orange]SD[/COLOR] '+fluxinfo ,5000 ,img)
          util.playMedia(titre, img, fluxsd.replace('\/','/').replace("pornfun.com","https://pornfun.com"), 'Video')
          ADDON.setSetting('getnbvideo', COUNTNB('{0}'.format(ADDON.getSetting( 'getnbvideo'))))

    else:
        util.showError(ADDON_ID, 'Could not open URL %s to get video information' % (video))
        ADDON.setSetting('getnberreur', COUNTNB('{0}'.format(ADDON.getSetting( 'getnberreur'))))
 



def playVideo(video ,title ,img):
    response = urllib2.urlopen(video)
    if response and response.getcode() == 200:
        content = response.read()
        VScreateDialogOK('test'+video)
        videoLink = util.extract(content, '<flux>', '</flux>')
        util.playMedia(title, img, videoLink, 'Video')
    else:
        util.showError(ADDON_ID, 'Could not open URL %s to get video information' % (video))
        ADDON.setSetting('getnberreur', COUNTNB('{0}'.format(ADDON.getSetting( 'getnberreur'))))

def video():
    global COUNT
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Synchronisation watiporn', 'Connections en cours')
    url = WEB_INDEX + 'view=ok'+ xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')
    rechurl = '{0}?action=rech&video={1}&title={2}&image={3}'.format(_url, WEB_INDEX + 'rech=dp', 'recherche', 'http://watiporn.com/media/categories/video/1.jpg')
    response = urllib2.urlopen(url)
    if response and response.getcode() == 200:
        content = response.read()
        videos = util.extractAll(content, '<cate>', '</cate>')
        util.addMenuItem('( [B]1Recherche[/B] )', rechurl, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/rech.png', True)
        for video in videos:
            info =  util.extract(video, '<pourcents>', '</pourcents>')
           
            if COUNT < 100:
             COUNT += 1
             time.sleep(tempprog)
            pDialog.update( COUNT, info)
            videourl = urllib.quote(WEB_PAGE_BASE + util.extract(video, '<loc>', '</loc>') + xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')) #code.php?ca=7
            img =  util.extract(video, '<img>', '</img>')
            title =  util.extract(video, '<title>', '</title>')
            link = '{0}?action=cat&categorie={4}{5}&video={1}&title={2}&image={3}'.format(_url, videourl, title, img, 'ca%3d', COUNT)
            util.addMenuItem(title, link, 'DefaultVideo.png', img, True)
        util.endListing()
    else:
        util.showError(ADDON_ID, 'Could not open URL %s to create menu' % (url))
        ADDON.setSetting('getnberreur', COUNTNB('{0}'.format(ADDON.getSetting( 'getnberreur'))))

def recherche():
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Recherche en cours ...', 'Demarrage de la recherche')
    global COUNT
    global pourcents
    keyboard = xbmc.Keyboard( '', 'Recherche watiporn', False )
    keyboard.doModal()
    searchstring = ' '
    if ( keyboard.isConfirmed() ):
     searchstring = keyboard.getText()
     pDialog.update( COUNT, 'Recherche watiporn :' + searchstring )
    url = WEB_INDEX + 'view=ok&viewrech=' + searchstring + "&page=1" + urllib.quote(xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin'))
    rechurl = '{0}?action=cat&categorie=rech51categweb51{4}&video={1}&title={2}&image={3}'.format(_url, WEB_INDEX + 'rech={1}{2}'.format('all', searchstring, urllib.quote('&page=1&'+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin'))), 'recherche', 'http://watiporn.com/media/categories/video/1.jpg',searchstring)
    response = urllib2.urlopen(url)
    if response and response.getcode() == 200:
        content = response.read()
        videos = util.extractAll(content, '<cate>', '</cate>')
        nb =  util.extract(content, '<nb>', '</nb>')
        #pourcents =  util.extract(content, '<pourcents>', '</pourcents>')
        #pourcents =  1.5
        util.addMenuItem('tout '+nb, rechurl, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/rech.png', True)
        for video in videos:
            info =  util.extract(video, '<pourcents>', '</pourcents>')
           
            if COUNT < 100:
             COUNT += 1
             time.sleep(tempprog)
            pDialog.update( COUNT, info)
            id =  util.extract(video, '<id>', '</id>')
            videourl = urllib.quote(WEB_PAGE_BASE + util.extract(video, '<loc>', '</loc>')+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin'))
            img =  util.extract(video, '<img>', '</img>')
            title =  util.extract(video, '<title>', '</title>')
            link = '{0}?action=cat&categorie={4}{5}&video={1}&title={2}&image={3}'.format(_url, videourl, title, img, 'ca51categweb51', COUNT)
            util.addMenuItem(title, link, 'DefaultVideo.png', img, True)
        pDialog.update( COUNT, 'Terminer ')

        util.endListing()
        pDialog.close()
    else:
        util.showError(ADDON_ID, 'Could not open URL %s to create menu' % (url))
        ADDON.setSetting('getnberreur', COUNTNB('{0}'.format(ADDON.getSetting( 'getnberreur'))))

def buildMenu2(url=None, categorie=None):
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Synchronisation videos', 'Demarrage de la Synchronisation videos')
    global COUNT
    pages = None
    xbmc.log("debug: {0}".format(url), xbmc.LOGERROR)
    xbmc.log("debug2: {0}".format(categorie), xbmc.LOGERROR)
    response = urllib2.urlopen(url)
    if response and response.getcode() == 200:
        content = response.read()
        videos = util.extractAll(content, '<video>', '</video>')
        for video in videos:
            info =  util.extract(video, '<pourcents>', '</pourcents>')
           
            if COUNT < 100:
             COUNT += 1
             time.sleep(tempprog)
            pDialog.update( COUNT, info)
            pagesmtn = util.extract(video, '<pagem>', '</pagem>')###
            pages = util.extract(video, '<page>', '</page>')###
            favoris = util.extract(video, '<favoris>', '</favoris>')###
            vid = util.extract(video, '<vid>', '</vid>')###
            hd = util.extract(video, '<hd>', '</hd>')###
            description = util.extract(video, '<description>', '</description>')###
            duration = util.extract(video, '<time>', '</time>')
            videourl = urllib.quote(WEB_PAGE_BASE + util.extract(video, '<loc>', '</loc>'))
            img =  util.extract(video, '<img>', '</img>')
            title =  str(util.extract(video, '<title>', '</title>').decode('latin-1').encode("utf-8"))

            link = '{0}?action=play&video={1}&title={2}&image={3}'.format(_url, videourl, title, img)
            util.addMenuItem(title, link, 'DefaultVideo.png', img, False, duration, vid, description, hd, img, favoris, xbmcplugin.getSetting(int(sys.argv[1]), 'login'), xbmcplugin.getSetting(int(sys.argv[1]), 'passe'))
        if pages:
         linkpage = '{0}?action=cat&categorie={3}&video={1}{2}'.format(_url, WEB_INDEX + categorie , urllib.quote('&page='+pages+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')), categorie)
         util.addMenuItem('Pages : '+pages, linkpage, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/pagenext.png', True)
        util.endListing()
        pDialog.close()        

    else:
        util.showError(ADDON_ID, 'Could not open URL %s to create menu' % (url))
        ADDON.setSetting('getnberreur', COUNTNB('{0}'.format(ADDON.getSetting( 'getnberreur'))))
		
def favoris(login=None, passe=None,vid=None,mode=None):
  url = '{0}login={1}&pass={2}'.format(WEB_INDEX, login, passe)
  response = urllib2.urlopen(url)
  if response and response.getcode() == 200:
     content = response.read()
     log = util.extract(content, '<etat>', '</etat>')
     prenom = util.extract(content, '<prenom>', '</prenom>')
     nom = util.extract(content, '<nom>', '</nom>') 
     token = util.extract(content, '<token>', '</token>')

     if log == 'ok':
      response = urllib2.urlopen('{0}favoris={4}&vid={3}&login={1}&pass={2}'.format(WEB_INDEX, login, passe, vid, mode))
      if response and response.getcode() == 200:
       content = response.read()
       favoris = util.extract(content, '<favoris>', '</favoris>')
       icon = util.extract(content, '<icon>', '</icon>')
       ADDON.setSetting('getnbvdf', COUNTNB('{0}'.format(ADDON.getSetting( 'getnbvdf'))))
       if mode == 'remove':
         util.notify(ADDON_ID, '{0}'.format(favoris),5000,icon)
         xbmc.executebuiltin('Container.Refresh')
       else:
         util.notify(ADDON_ID, '{0}'.format(favoris),5000,icon)
      else:
       util.showError(ADDON_ID, 'Video invalides!')
       ADDON.setSetting('getnberreur', COUNTNB('{0}'.format(ADDON.getSetting( 'getnberreur'))))
     else:
      util.showError(ADDON_ID, 'Pseudo ou mot de passe invalides!')
      ADDON.setSetting('getnberreur', COUNTNB('{0}'.format(ADDON.getSetting( 'getnberreur'))))
  else:
     util.showError(ADDON_ID, 'Pseudo ou mot de passe invalides!')
     ADDON.setSetting('getnberreur', COUNTNB('{0}'.format(ADDON.getSetting( 'getnberreur'))))

def mlogin(login=None, passe=None, token=None, etat=None):
  if urllib.quote(xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')):
    url = '{0}{1}'.format(WEB_INDEX, xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin'))
  else:
    url = '{0}login={1}&pass={2}'.format(WEB_INDEX, login, passe)
  req = urllib2.Request(url)
#  req.add_header('Cookie', 'token={0}'.format(token))
# Customize the default User-Agent header value:
#  req.add_header('User-Agent', 'urllib-example/0.1 (Contact: . . .)')
  response = urllib2.urlopen(req)
  if response and response.getcode() == 200:
     content = response.read()
     log = util.extract(content, '<etat>', '</etat>')
     prenom = util.extract(content, '<prenom>', '</prenom>')
     nom = util.extract(content, '<nom>', '</nom>') 
     token = util.extract(content, '<token>', '</token>')
     mail = util.extract(content, '<mail>', '</mail>')
     img = util.extract(content, '<img>', '</img>') 
     premium = util.extract(content, '<premium>', '</premium>')
     if etat == 'deco':

       oDialog = xbmcgui.Dialog()
       qst = oDialog.yesno("watiporn", 'voulez vous vraiment vous deconnecter ?')

       if qst == 1:
        ADDON.setSetting('acceslogin', None )
        ADDON.setSetting('login', None)
        ADDON.setSetting('passe', None)
        ADDON.setSetting('wpnom', None )
        ADDON.setSetting('wpprenom', None )
        ADDON.setSetting('wpmail', None )
        ADDON.setSetting('wppremium', None )
        xbmc.executebuiltin("XBMC.Container.Update({0},replace)".format(_url))
        menu2()
       #util.endListing()
     elif log == 'ok':
       #conection ok
       ADDON.setSetting('wpnom', nom )
       ADDON.setSetting('wpprenom', prenom )
       ADDON.setSetting('wpmail', mail )
       ADDON.setSetting('wppremium', premium )
       ADDON.setSetting('getnblogin', COUNTNB('{0}'.format(ADDON.getSetting( 'getnblogin'))))
       util.notify(ADDON_ID, 'Bienvenue : {0} {1}'.format(prenom, nom),5000,img)
       linkdeco = '{0}?action=mlogin&login={1}&passe={2}&token={3}&etat={4}'.format(_url, 'null', 'null', 'null' ,'deco')
       util.addMenuItem('deconections', linkdeco, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/deco.png', True)
       menu()



     elif etat == 'login':
       # login input
       keyboard = xbmc.Keyboard( '', 'login', False )
       keyboard.doModal()
       if ( keyboard.isConfirmed() ):
        login = keyboard.getText()
        keyboard = xbmc.Keyboard( '', 'mots de passe', False )
        keyboard.doModal()
        if ( keyboard.isConfirmed() ):
         passe = keyboard.getText()

         ADDON.setSetting('acceslogin', '&login={0}&pass={1}'.format(login, passe))
         ADDON.setSetting('login', login)
         ADDON.setSetting('passe', passe)
         resourcelogin = xbmcplugin.getSetting(int(sys.argv[1]), 'login')
         resourcepass = xbmcplugin.getSetting(int(sys.argv[1]), 'passe')
         mlogin(login, passe, 'null', 'ok')
     else:
       util.showError(ADDON_ID, 'Pseudo ou mot de passe invalides!')
       ADDON.setSetting('getnberreur', COUNTNB('{0}'.format(ADDON.getSetting( 'getnberreur'))))
       menu2()

  else:
       util.showError(ADDON_ID, 'Could not open URL %s to create menu' % (url))
       ADDON.setSetting('getnberreur', COUNTNB('{0}'.format(ADDON.getSetting( 'getnberreur'))))
def menu():
       linkvideo = '{0}?action=video'.format(_url)
       linkvideotop = '{0}?action=cat&categorie=viewtop&video={1}{2}'.format(_url, WEB_INDEX + 'viewtop=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideovue = '{0}?action=cat&categorie=viewvue&video={1}{2}'.format(_url, WEB_INDEX + 'viewvue=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideobw = '{0}?action=cat&categorie=viewbw&video={1}{2}'.format(_url, WEB_INDEX + 'viewbw=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideolg = '{0}?action=cat&categorie=viewlg&video={1}{2}'.format(_url, WEB_INDEX + 'viewlg=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideohd = '{0}?action=cat&categorie=viewhd&video={1}{2}'.format(_url, WEB_INDEX + 'viewhd=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideofavorite = '{0}?action=cat&categorie=viewfavorite&video={1}{2}'.format(_url, WEB_INDEX + 'viewfavorite=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideopremium = '{0}?action=cat&categorie=viewpremium&video={1}{2}'.format(_url, WEB_INDEX + 'viewpremium=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkRechercheWeb = '{0}?action=rechercheweb'.format(_url)
       linkphoto = '{0}?action=photo'.format(_url)
       #xbmc.log("url: {0}".format(linkvideo), xbmc.LOGERROR)
       #xbmc.log("linkvideotop: {0}".format(linkvideotop), xbmc.LOGERROR)
       #xbmc.log("linkvideovue: {0}".format(linkvideovue), xbmc.LOGERROR)
       #xbmc.log("linkvideobw: {0}".format(linkvideobw), xbmc.LOGERROR)
       #xbmc.log("linkvideolg: {0}".format(linkvideolg), xbmc.LOGERROR)
       #xbmc.log("linkvideohd: {0}".format(linkvideohd), xbmc.LOGERROR)
       #xbmc.log("linkvideofavorite: {0}".format(linkvideofavorite), xbmc.LOGERROR)
       #xbmc.log("linkvideopremium: {0}".format(linkvideopremium), xbmc.LOGERROR)
      # xbmc.log("linkRechercheWeb: {0}".format(linkRechercheWeb), xbmc.LOGERROR)
	   
       util.addMenuItem('Videos', linkvideo, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/video.png', True)
       util.addMenuItem('Top Classement', linkvideotop, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videotop.png', True)
       util.addMenuItem('Plus vu ', linkvideovue, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videovue.png', True)
       util.addMenuItem('Vu en ce moment', linkvideobw, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videovm.png', True)
       util.addMenuItem('Plus long ', linkvideolg, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videolg.png', True)
       util.addMenuItem('Videos hd', linkvideohd, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videohd.png', True)
       util.addMenuItem('Videos favorite', linkvideofavorite, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/favorite.png', True)
       util.addMenuItem('Videos premium', linkvideopremium, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videopremium.png', True)
       util.addMenuItem('Recherche Web ', linkRechercheWeb, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/host.png', True)
       #util.addMenuItem('Photo', linkphoto, 'DefaultPhoto.png', WEB_PAGE_BASE + 'icon/photo.png', True)
       util.endListing() 
       
def menu2():
       linklogin = '{0}?action=mlogin&login={1}&passe={2}&token={3}&etat={4}'.format(_url, 'null', 'null', 'null' ,'login')
       util.addMenuItem('login', linklogin, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/login.png', True)


       linkvideo = '{0}?action=video'.format(_url)
       linkvideo = '{0}?action=video'.format(_url)
       linkvideotop = '{0}?action=cat&categorie=viewtop&video={1}{2}'.format(_url, WEB_INDEX + 'viewtop=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideovue = '{0}?action=cat&categorie=viewvue&video={1}{2}'.format(_url, WEB_INDEX + 'viewvue=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideobw = '{0}?action=cat&categorie=viewbw&video={1}{2}'.format(_url, WEB_INDEX + 'viewbw=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideolg = '{0}?action=cat&categorie=viewlg&video={1}{2}'.format(_url, WEB_INDEX + 'viewlg=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
      # linkvideohd = '{0}?action=cat&categorie=viewhd&video={1}{2}'.format(_url, WEB_INDEX + 'viewhd=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
      # linkvideofavorite = '{0}?action=cat&categorie=viewfavorite&video={1}{2}'.format(_url, WEB_INDEX + 'viewfavorite=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
      # linkvideopremium = '{0}?action=cat&categorie=viewpremium&video={1}{2}'.format(_url, WEB_INDEX + 'viewpremium=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
   

   
       linkphoto = '{0}?action=photo'.format(_url)

       util.addMenuItem('Videos', linkvideo, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/video.png', True)
       util.addMenuItem('Top Classement', linkvideotop, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videotop.png', True)
       util.addMenuItem('Plus vu ', linkvideovue, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videovue.png', True)
       util.addMenuItem('Vu en ce moment', linkvideobw, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videovm.png', True)
       util.addMenuItem('Plus long ', linkvideolg, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videolg.png', True)
       #util.addMenuItem('Videos hd', linkvideohd, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videohd.png', True)
       #util.addMenuItem('Videos premium', linkvideopremium, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videopremium.png', True)
       #util.addMenuItem('Photo', linkphoto, 'DefaultPhoto.png', WEB_PAGE_BASE + 'icon/photo.png', True)
       util.endListing()

def config():

  dialog = xbmcgui.Dialog()
  age = dialog.yesno('AVERTISSEMENT: cet addon contient du matériel pour adultes.','Vous ne pouvez entrer que si vous avez au moins 18 ans.', nolabel='Quitter', yeslabel='Entrer')
  if age == 1:
   dialog.ok('Configuration Terminer', "La configuration est terminé merci d'avoir choisi watiporn.com")
   ADDON.setSetting('uwcage','true')   
   ADDON.setSetting('age','true')
#   if conficheck == 1:

#    comptercheck = dialog.yesno('Configuration : ','Avez-vous déjà un compte watiporn ?.', nolabel='Non', yeslabel='Oui')
#    if comptercheck == 1:
#     logincheck = dialog.yesno('Configuration : ','Voulez-vous vous connecter maintenant ?', nolabel='Non', yeslabel='Oui')
#     if logincheck == 1:
#   #   dialog.ok('terminerr', "0000")# ici l etape login
#     else:
#   #   compteurcheck = dialog.yesno('Configuration : ',"Voulez-vous activer le compteur de nombre de recherches . Attention l'activation du compteur peut ralentir la vitesse de recherche !", nolabel='Non', yeslabel='Oui')
#   #   if compteurcheck == 1:
#   #    #ici activation compteur
#   #    terminer = dialog.ok('Configuration Terminer', "La configuration est terminé merci d'avoir choisi watiporn.com")
#   #   ADDON.setSetting('uwcage','true')
#   #   starting()
#    else:
#     creercomptecheck = dialog.yesno('Configuration : ','Voulez-vous creer un compter watiporn ?.', nolabel='Non', yeslabel='Oui')
#     if creercomptecheck == 1:
#   #   # ici iscription watiporn
#   #   dialog.ok('Configuration Terminer', "La configuration est terminé merci d'avoir choisi watiporn.com")
#   #   ADDON.setSetting('uwcage','true')
#   #   starting()
#     else:
#   #   compteurcheck = dialog.yesno('Configuration : ',"Voulez-vous activer le compteur de nombre de recherches . Attention l'activation du compteur peut ralentir la vitesse de recherche !", nolabel='Non', yeslabel='Oui')
#   #   if compteurcheck == 1:
#   #    #ici activation compteur
#   #    terminer = dialog.ok('Configuration Terminer', "La configuration est terminé merci d'avoir choisi watiporn.com")
#   #    ADDON.setSetting('uwcage','true')
#   #    starting()
#   else:
#    dialog.ok('Configuration Terminer', "La configuration est terminé merci d'avoir choisi watiporn.com")
#    ADDON.setSetting('uwcage','true')
#    starting()
  else:
    dialog.ok('Configuration Terminer', "La configuration est terminé merci d'avoir choisi watiporn.com")
    #ADDON.setSetting('uwcage','true')
  return
  

def desacontroleparental():
      keyboard = xbmc.Keyboard( '', 'Contrôle parental : code', False )
      keyboard.doModal()
      searchstring = ' '
      if ( keyboard.isConfirmed() ):
       searchstring = keyboard.getText()
       if xbmcplugin.getSetting(int(sys.argv[1]), 'controlparentalpasse') == searchstring:
        ADDON.setSetting('controlparental','false')
       else:
        VScreateDialogOK('Code invalide')


def starting():
  if params:
     if params['action'] == 'play':
      codex(params['video'] ,params['title'] ,params['image'])
     elif params['action'] == 'cat':
      buildMenu2(params['video'],params['categorie'])
     elif params['action'] == 'rech':
      recherche()
     elif params['action'] == 'video':
      video()
     elif params['action'] == 'mlogin':
      mlogin(params['login'], params['passe'], params['token'], params['etat'])
     elif params['action'] == 'addfavoris':
      favoris(params['login'], params['passe'],params['vid'], 'add')
     elif params['action'] == 'removefavoris':
      favoris(params['login'], params['passe'],params['vid'], 'remove')
     elif params['action'] == 'refresh':
      refresh(params['run'])
     elif params['action'] == 'desacontroleparental':
      desacontroleparental()
     elif params['action'] == 'downloads':
      downloadsfile(params['vid'])
     elif params['action'] == 'rechercheweb':
      recherchevidweb(WEB_INDEX)
     elif params['action'] == 'rechdocwebbtn':
      rechdocweb(params['nomsite'], params['urlrech'],params['urlcate'])
     elif params['action'] == 'rechvideowebbtn':
      rechvideoweb(params['nomsite'], params['url'], params['page'])
     elif params['action'] == 'mediaplayerbtn':
      mediaplayer(params['nomsite'], params['url'], params['titre'],params['img'])
     elif params['action'] == 'rechwebkeyboardbtn':
      rechwebkeyboard(params['nomsite'], params['url'], params['mode'], params['url2'])
     elif params['action'] == 'recherchevidwebglobalbtn':
      recherchevidwebglobal(params['search'], params['mode'], params['pages'])
     elif params['action'] == 'downloadsfilewebbtn':
      downloadsfileweb(params['nomsite'],params['url'], params['titre'])
  else:

     if resourcelogin:
      if resourcepass:
       mlogin()
      else:
       menu2()
     else:
      menu2()
  return






def VScreateDialogOK(label):
    oDialog = xbmcgui.Dialog()
    oDialog.ok('watiporn', label)  
    return oDialog

def refresh(run):
    xbmc.executebuiltin("XBMC.Container.Update({0},replace)".format(_url))
    xbmc.executebuiltin("XBMC.Container.Update("+run+",replace)")
    return
    
def VScreateDialogYesNo(label):
    oDialog = xbmcgui.Dialog()
    qst = oDialog.yesno("watiporn", label)
    return qst

def VScreateDialogSelect(label):
    oDialog = xbmcgui.Dialog()
    ret = oDialog.select('Select Quality', label)  
    return ret

def createDialog(sSite):
    oDialog = xbmcgui.DialogProgress()
    oDialog.create(sSite,None)
    return oDialog

def pourcentRech(value,txt):
 pDialog = xbmcgui.DialogProgress()
 pDialog.update(1, txt + str(value) + '%')
 return oDialog
      
def updateDialog(dialog,total):
    global COUNT
    COUNT += 1
    if xbmcgui.Window(10101).getProperty('search') != 'true':
        iPercent = int(float(COUNT * 100) / total)
        dialog.update(iPercent, 'Chargement: '+str(COUNT)+'/'+str(total))

def COUNTNB(COUNT2=0):
    #global COUNT
    COUNT2 = int(COUNT2) + 1
    return '{0}'.format(COUNT2)

def checkopen():
 ADDON.setSetting('controlparentaldata','true')
 return 
 

 
