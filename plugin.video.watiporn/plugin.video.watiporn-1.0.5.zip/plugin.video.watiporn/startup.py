# -*- coding: utf-8 -*-
import urllib
import os,sys
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
addon  = xbmcaddon.Addon()
url_path = '{0}?{1}'.format(sys.argv[0],sys.argv[2][1:])
url_plugin = '{0}?'.format(sys.argv[0])
setup = xbmcplugin.getSetting(int(sys.argv[1]), 'setup')
controlparental = xbmcplugin.getSetting(int(sys.argv[1]), 'controlparental')
controlparentalpasse = xbmcplugin.getSetting(int(sys.argv[1]), 'controlparentalpasse')
__addon__      = xbmcaddon.Addon(id='plugin.video.watiporn')
__language__   = __addon__.getLocalizedString
__cwd__        = __addon__.getAddonInfo('path')

from resources.lib.watiporn import * 
from resources.lib.util import * 
from resources.lib.rechercheweb import * 

xbmcplugin.setContent(int(sys.argv[1]), 'movies')
if __name__ == '__main__':

 
 if not addon.getSetting('uwcage') == 'true':
  config()
 else:
  if url_path == url_plugin:
   if controlparental == 'true':
      keyboard = xbmc.Keyboard( '', 'Contrôle parental : code', False )
      keyboard.doModal()
      searchstring = ' '
      if ( keyboard.isConfirmed() ):
       searchstring = keyboard.getText()
       if controlparentalpasse == searchstring:

        starting()
       else:
        VScreateDialogOK('Code invalide')
   else:
    starting()
  else:
   starting()




