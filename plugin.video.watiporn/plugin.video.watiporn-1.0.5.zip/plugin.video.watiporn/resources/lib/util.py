# -*- coding: utf-8 -*-

import sys, urllib
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import re
import urllib
import urllib2

import cookielib
import os.path
ADDON_ID = 'plugin.video.watiporn'
import time
import tempfile
import sqlite3
import urlparse
import base64
from StringIO import StringIO
import gzip
addon = xbmcaddon.Addon()
import xbmcvfs
import htmlentitydefs
import unicodedata
COUNT = 0
def playMedia(title, thumbnail, link, mediaType='Video') :
    """Plays a video

    Arguments:
    title: the title to be displayed
    thumbnail: the thumnail to be used as an icon and thumbnail
    link: the link to the media to be played
    mediaType: the type of media to play, defaults to Video. Known values are Video, Pictures, Music and Programs
    """
    li = xbmcgui.ListItem(label=title, iconImage=thumbnail, thumbnailImage=thumbnail, path=link)
    li.setInfo(type=mediaType, infoLabels={ "Title": title })
    xbmc.Player().play(item=link, listitem=li)

def parseParameters(inputString=sys.argv[2]):
    """Parses a parameter string starting at the first ? found in inputString
    
    Argument:
    inputString: the string to be parsed, sys.argv[2] by default
    
    Returns a dictionary with parameter names as keys and parameter values as values
    """
    parameters = {}
    p1 = inputString.find('?')
    if p1 >= 0:
        splitParameters = inputString[p1 + 1:].split('&')
        for nameValuePair in splitParameters:
            if (len(nameValuePair) > 0):
                pair = nameValuePair.split('=')
                key = pair[0]
                value = urllib.unquote(urllib.unquote_plus(pair[1])).decode('utf-8')
                parameters[key] = value
    return parameters

def notify(addonId, message, timeShown=5000, icon=addon.getAddonInfo('icon')):
    """Displays a notification to the user
    
    Parameters:
    addonId: the current addon id
    message: the message to be shown
    timeShown: the length of time for which the notification will be shown, in milliseconds, 5 seconds by default
    """
    addon = xbmcaddon.Addon(addonId)
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)' % (addon.getAddonInfo('name'), message, timeShown, icon))


def showError(addonId, errorMessage):
    """
    Shows an error to the user and logs it
    
    Parameters:
    addonId: the current addon id
    message: the message to be shown
    """
    notify(addonId, errorMessage)
    xbmc.log(errorMessage, xbmc.LOGERROR)

def extractAll(text, startText, endText):
    """
    Extract all occurences of a string within text that start with startText and end with endText
    
    Parameters:
    text: the text to be parsed
    startText: the starting tokem
    endText: the ending token
    
    Returns an array containing all occurences found, with tabs and newlines removed and leading whitespace removed
    """
    result = []
    start = 0
    pos = text.find(startText, start)
    while pos != -1:
        start = pos + startText.__len__()
        end = text.find(endText, start)
        result.append(text[start:end].replace('\n', '').replace('\r', '').replace('  ', '').replace('\t', '').lstrip())
        pos = text.find(startText, end)
    return result

def extract(text, startText, endText):
    """
    Extract the first occurence of a string within text that start with startText and end with endText
    
    Parameters:
    text: the text to be parsed
    startText: the starting tokem
    endText: the ending token
    
    Returns the string found between startText and endText, or None if the startText or endText is not found
    """
    start = text.find(startText, 0)
    if start != -1:
        start = start + startText.__len__()
        end = text.find(endText, start + 1)
        if end != -1:
            return text[start:end]
    return None
    
def makeLink(params, baseUrl=sys.argv[0]):
    """
    Build a link with the specified base URL and parameters
    
    Parameters:
    params: the params to be added to the URL
    BaseURL: the base URL, sys.argv[0] by default
    """
    return baseUrl + '?' +urllib.urlencode(dict([k.encode('utf-8'),unicode(v).encode('utf-8')] for k,v in params.items()))

def addMenuItemwebvideo(caption, link, icon=None, thumbnail=None, folder=False, duration=None, vid=None, description=None, hd=None, Fanart='http://api.watiporn.com/xmbc/icon/fanart.jpg', url=None,nomsite=None):
    """
    Add a menu item to the xbmc GUI
    
    Parameters:
    caption: the caption for the menu item
    icon: the icon for the menu item, displayed if the thumbnail is not accessible
    thumbail: the thumbnail for the menu item
    link: the link for the menu item
    folder: True if the menu item is a folder, false if it is a terminal menu item
    
    Returns True if the item is successfully added, False otherwise
    """
    rootDir = addon.getAddonInfo('path')
    if rootDir[-1] == ';':
     rootDir = rootDir[0:-1]
    rootDir = xbmc.translatePath(rootDir)
    resDir = os.path.join(rootDir, 'resources')
    imgDir = os.path.join(resDir, 'images')

    listItem = xbmcgui.ListItem(unicode(caption), iconImage=icon, thumbnailImage=thumbnail)
    listItem.setInfo(type="Video", infoLabels={ "Title": caption, "Plot": description })
    listItem.setProperty( "Fanart_Image", Fanart )
    #listItem.setProperty( "Build.Video", video )
    contextMenuItems = []
    #VScreateDialogOK(resDir)
    '''
    listItem.setProperty("channel", sitem['Channel'])
    listItem.setArt("Poster"), sitem['Poster']
    listItem.setProperty("plot", sitem['Description'])
    listItem.setProperty("staffel", sitem['Staffel'])
    listItem.setProperty("episode", '6')
    listItem.setProperty("starttime", '6')
    listItem.setProperty("rating", '6')
    listItem.setProperty("senderlogo", thumbnail)
    listItem.setProperty("genre", '6')
    listItem.setProperty("date", '12-03-11')
    listItem.setProperty("rumtime", '6')
    listItem.setProperty("studio", '6')
    listItem.setProperty("year", '4')
    listItem.setProperty("altersfreigabe", '3')
    listItem.setProperty("status", '2')'''
    if hd == 'hd':
     hd = 1280
    elif hd == 'sd':
     hd = 100
    elif hd == None:
     hd = 0

    downloadertx = (sys.argv[0] + "?action=downloadsfilewebbtn&nomsite="+nomsite+"&titre="+caption+"&url="+url)
    contextMenuItems.append((nomsite+' [COLOR hotpink]Telecharger[/COLOR]',  'xbmc.RunPlugin('+downloadertx+')'))

    listItem.addContextMenuItems(contextMenuItems, replaceItems=True)



    listItem.addStreamInfo('video', { 'duration': duration , 'width' : hd, 'height' : 100 })
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=link, listitem=listItem, isFolder=folder)


def addMenuItem(caption, link, icon=None, thumbnail=None, folder=False, duration=None, vid=None, description=None, hd=None, Fanart='http://api.watiporn.com/xmbc/icon/fanart.jpg', favoris=None, login=None, passe=None):
    """
    Add a menu item to the xbmc GUI
    
    Parameters:
    caption: the caption for the menu item
    icon: the icon for the menu item, displayed if the thumbnail is not accessible
    thumbail: the thumbnail for the menu item
    link: the link for the menu item
    folder: True if the menu item is a folder, false if it is a terminal menu item
    
    Returns True if the item is successfully added, False otherwise
    """
    rootDir = addon.getAddonInfo('path')
    if rootDir[-1] == ';':
     rootDir = rootDir[0:-1]
    rootDir = xbmc.translatePath(rootDir)
    resDir = os.path.join(rootDir, 'resources')
    imgDir = os.path.join(resDir, 'images')

    listItem = xbmcgui.ListItem(unicode(caption), iconImage=icon, thumbnailImage=thumbnail)
    listItem.setInfo(type="Video", infoLabels={ "Title": caption, "Plot": description })
    listItem.setProperty( "Fanart_Image", Fanart )
    #listItem.setProperty( "Build.Video", video )
    contextMenuItems = []
    #VScreateDialogOK(resDir)
    '''
    listItem.setProperty("channel", sitem['Channel'])
    listItem.setArt("Poster"), sitem['Poster']
    listItem.setProperty("plot", sitem['Description'])
    listItem.setProperty("staffel", sitem['Staffel'])
    listItem.setProperty("episode", '6')
    listItem.setProperty("starttime", '6')
    listItem.setProperty("rating", '6')
    listItem.setProperty("senderlogo", thumbnail)
    listItem.setProperty("genre", '6')
    listItem.setProperty("date", '12-03-11')
    listItem.setProperty("rumtime", '6')
    listItem.setProperty("studio", '6')
    listItem.setProperty("year", '4')
    listItem.setProperty("altersfreigabe", '3')
    listItem.setProperty("status", '2')'''
    if hd == 'hd':
     hd = 1280
    elif hd == 'sd':
     hd = 100
    elif hd == None:
     hd = 0

    if favoris == 'add':
     downloadertx = (sys.argv[0] + "?action=downloads&vid="+vid)
     contextMenuItems.append(('[COLOR hotpink]Telecharger[/COLOR]',  'xbmc.RunPlugin('+downloadertx+')'))
     favorite = (sys.argv[0] + "?action=addfavoris&vid="+vid+"&login="+login+"&passe="+passe)
     contextMenuItems.append(('[COLOR hotpink]Ajouter aux favoris watiporn[/COLOR]', 'xbmc.RunPlugin('+favorite+')'))
     listItem.addContextMenuItems(contextMenuItems, replaceItems=True)
    elif favoris == 'remove':
     downloadertx = (sys.argv[0] + "?action=downloads&vid="+vid)
     contextMenuItems.append(('[COLOR hotpink]Telecharger[/COLOR]',  'xbmc.RunPlugin('+downloadertx+')'))
     favorite = (sys.argv[0] + "?action=removefavoris&vid="+vid+"&login="+login+"&passe="+passe)
     contextMenuItems.append(('[COLOR hotpink]Retirer des favoris watiporn[/COLOR]',  'xbmc.RunPlugin('+favorite+')'))
     listItem.addContextMenuItems(contextMenuItems, replaceItems=True)
    elif favoris == None:
     null=''



    listItem.addStreamInfo('video', { 'duration': duration , 'width' : hd, 'height' : 100 })
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=link, listitem=listItem, isFolder=folder)






def DownloaderClass(url,dest,nom,img,info):
 notify(ADDON_ID, info ,5000 ,img)
 dp = xbmcgui.DialogProgressBG()
 dp.create('Telechargements',nom)
 file_name = dest #url.split('/')[-1]
 req = urllib2.Request(url)
 req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
 req.add_header('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
 req.add_header('Accept', '*/*')
 req.add_header('Accept','text/html')
 u = urllib2.urlopen(req)
 f = open(file_name, 'wb')
 meta = u.info()
 file_size = int(meta.getheaders("Content-Length")[0])
 #print("Downloading: {0} Bytes: {1}".format(url, file_size))
 xbmc.log("Downloading: {0} Bytes: {1}".format(url, file_size), xbmc.LOGERROR)
 file_size_dl = 0
 block_sz = 8192
 while True:
    buffer = u.read(block_sz)
    if not buffer:
        break

    file_size_dl += len(buffer)
    f.write(buffer)
    p = float(file_size_dl) / file_size
    pourcent = "{0:.0%}".format(p).replace('%','').replace(' ','')
    xbmc.log(pourcent, xbmc.LOGERROR)
    percent = min((file_size_dl*100)/file_size, 100)
    dp.update(percent)
    if dp.isFinished(): 
      dp.close()
      notify(ADDON_ID, 'Terminer:'+nom ,5000 ,img)
    status = r"{0}  [{1:.2%}]".format(file_size_dl, p)
    status = status + chr(8)*(len(status)+1)
    #sys.stdout.write(status)
    xbmc.log("Downloading: {0} Bytes: {1}".format(url, file_size), xbmc.LOGERROR)

 f.close()
 dp.close()
 notify(ADDON_ID, 'Terminer:'+nom ,5000 ,img)
percent = 0
def DownloaderClass2(url,dest,nom,img,info):

    xbmc.log(url, xbmc.LOGERROR)
    notify(ADDON_ID, info ,5000 ,img)
    dp = xbmcgui.DialogProgressBG()
    dp.create('Telechargements',nom)
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp,nom,info,img))
 
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None,nom=None, info=None,img=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
        if dp.isFinished(): 
         dp.close()
         notify(ADDON_ID, 'Terminer:'+nom ,5000 ,img)     

    except: 
        percent = 100
        dp.update(percent,heading='Terminer')
        time.sleep(20)
        dp.close()
        notify(ADDON_ID, 'Terminer:'+ nom,5000 ,img)
    if dp.isFinished(): 
        dp.close()
        notify(ADDON_ID, 'Terminer:'+nom ,5000 ,img)


def endListing():
    """
    Signals the end of the menu listing
    """
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def VScreateDialogOK(label):
    oDialog = xbmcgui.Dialog()
    oDialog.ok('vStream', label)  
    return oDialog
    
def VScreateDialogYesNo(label):
    oDialog = xbmcgui.Dialog()
    qst = oDialog.yesno("vStream", label)
    return qst

def VScreateDialogSelect(label):
    oDialog = xbmcgui.Dialog()
    ret = oDialog.select('Select Quality', label)  
    return ret

def createDialog(sSite):
    oDialog = xbmcgui.DialogProgress()
    oDialog.create(sSite,None)
    return oDialog
   
def updateDialog(dialog,total):
    global COUNT
    COUNT += 1
    if xbmcgui.Window(10101).getProperty('search') != 'true':
        iPercent = int(float(COUNT * 100) / total)
        dialog.update(iPercent, 'Chargement: '+str(COUNT)+'/'+str(total))
