# -*- coding: utf-8 -*-
import sys
from urlparse import parse_qsl
import xbmcgui
import xbmcplugin
import urllib2
import urllib
import xbmc, xbmcaddon
import util
import htmlentitydefs
import unicodedata
import math
import time
from resources.lib.watiporn import * 
from resources.lib.util import * 
_url = sys.argv[0]
ADDON        = xbmcaddon.Addon()
WEB_INDEX = 'http://api.watiporn.com/xmbc/code.php?'
ADDON_ID = 'plugin.video.watiporn'
WEB_PAGE_BASE = 'http://api.watiporn.com/xmbc/'

def downloadsfileweb(nomsite,urldata,titre):
  
  if ADDON.getSetting('download_path') == '...':
   __dialog = xbmcgui.Dialog()
   dir = __dialog.browse( 3,"Downloads","files" )
   if dir:
    ADDON.setSetting('download_path',dir)
    downloadsfileweb(nomsite,urldata)
  else:
    url = WEB_INDEX + 'getdecode=' + nomsite 
    response = urllib2.urlopen(url)
    if response and response.getcode() == 200:
     content = response.read()
     fluxsd1 =  util.extract(content, '<fluxsd1>', '</fluxsd1>').replace('<fluxsd1>','').replace('</fluxsd1>','')
     fluxsd2 =  util.extract(content, '<fluxsd2>', '</fluxsd2>').replace('<fluxsd2>','').replace('</fluxsd2>','')
     fluxhd1 =  util.extract(content, '<fluxhd1>', '</fluxhd1>').replace('<fluxhd1>','').replace('</fluxhd1>','')
     fluxhd2 =  util.extract(content, '<fluxhd2>', '</fluxhd2>').replace('<fluxhd2>','').replace('</fluxhd2>','')
     vidimg1 =  util.extract(content, '<vidimg1>', '</vidimg1>').replace('<vidimg1>','').replace('</vidimg1>','')
     vidimg2 =  util.extract(content, '<vidimg2>', '</vidimg2>').replace('<vidimg2>','').replace('</vidimg2>','')
     vidtitre1 =  util.extract(content, '<vidtitre1>', '</vidtitre1>').replace('<vidtitre1>','').replace('</vidtitre1>','')
     vidtitre2 =  util.extract(content, '<vidtitre2>', '</vidtitre2>').replace('<vidtitre2>','').replace('</vidtitre2>','')
     fluxinfo =  util.extract(content, '<fluxinfo>', '</fluxinfo>').replace('<fluxinfo>','').replace('</fluxinfo>','')

     req = urllib2.Request(urldata)
     req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
     ##req.add_header('X-Requested-With', 'XMLHttpRequest')
     req.add_header('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
     req.add_header('Accept', '*/*')
     #req.add_header('Accept-Encoding', 'gzip, deflate')
     #req.add_header('Accept-Language', 'en-US,en;q=0.8,nl;q=0.6')
     #req.add_header('Connection', 'keep-alive')
     req.add_header('Accept','text/html')
     response2 = urllib2.urlopen(req)
     if response2 and response2.getcode() == 200:
      content2 = response2.read()
      info = 'Telechargement en cours ..'
      title = titre.replace(' ','_')
      dest = ADDON.getSetting('download_path') + title + '_watiporn.com.mp4'
      img = util.extract(content2, vidimg1, vidimg2)
      if fluxsd1:
        fluxsd =  util.extract(content2, fluxsd1, fluxsd2)
      if fluxhd1:
        fluxhd =  util.extract(content2, fluxhd1, fluxhd2)

      if fluxhd:
          #VScreateDialogOK('hd '+fluxhd)
          util.DownloaderClass(str(fluxhd).replace('.mp4/','.mp4').replace('\/','/').replace("pornfun.com","https://pornfun.com"),dest,title,img,info)
      else:
          #VScreateDialogOK('sd '+fluxsd)
          util.DownloaderClass(str(fluxsd).replace('.mp4/','.mp4').replace('\/','/').replace("pornfun.com","https://pornfun.com"),dest,title,img,info)

     else:
      util.showError(ADDON_ID, 'erreur decode : serveur')
 
    else:
     util.showError(ADDON_ID, 'erreur decode : serveur')

def recherchevidwebglobal(searchstring=None,mode='1',pages='1'):
 global COUNT
 global pourcents
 if mode == '1' :
    keyboard = xbmc.Keyboard( '', 'Recherche global', False )
    keyboard.doModal()
    searchstring = ' '
    if ( keyboard.isConfirmed() ):
     searchstring = keyboard.getText()
     recherchevidwebglobal(searchstring,'2','1')
 elif mode == '2' :

     url = WEB_INDEX + 'rechweb=ok' + urllib.quote(xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin'))
     response = urllib2.urlopen(url)
     if response and response.getcode() == 200:
         content = response.read()
         datas = util.extractAll(content, '<serversite>', '</serversite>')
         COUNT = 1
         FINCOUNT = 0
         for data in datas:
          FINCOUNT += 1
         pDialog = xbmcgui.DialogProgress()
         pDialog.create('Recherche en cours ...', 'Demarrage de la recherche')
         for data in datas:
             name =  util.extract(data, '<name>', '</name>')
             siteurl1 = util.extract(data, '<loc1>', '</loc1>')

             img =  util.extract(data, '<img>', '</img>')
             description =  util.extract(data, '<description>', '</description>')
             urlrecherhe = siteurl1.replace('/[icirecherche]/',str(searchstring)).replace('/[icicategories]/','')
             rechvideoweb2(name, urlrecherhe, str(pages))
             PROGCOUNT = int(float(COUNT * 100) / FINCOUNT)
             pDialog.update( PROGCOUNT, 'Chargement : '+str(COUNT)+'/'+str(FINCOUNT)+ ' - '+str(name))
             COUNT += 1
         link = '{0}?action=recherchevidwebglobalbtn&search={1}&mode={2}&pages={3}'.format(_url, searchstring, '2',str(COUNTNB(pages)))
         util.addMenuItem('Pages : '+str(pages), link, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/rech2.png', True, None, None, 'test')


         util.endListing()
     else:
         util.showError(ADDON_ID, 'Could not open URL %s to create menu' % (url))
         ADDON.setSetting('getnberreur', COUNTNB('{0}'.format(ADDON.getSetting( 'getnberreur'))))

def recherchevidweb(WEB_INDEX):
    url = WEB_INDEX + 'rechweb=ok' + urllib.quote(xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin'))
    response = urllib2.urlopen(url)
    if response and response.getcode() == 200:
        content = response.read()
        videos = util.extractAll(content, '<serversite>', '</serversite>')
        #nb =  util.extract(content, '<nb>', '</nb>')
        #pourcents =  util.extract(content, '<pourcents>', '</pourcents>')
        #pourcents =  1.5
        #util.addMenuItem('tout '+nb, rechurl, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/rech.png', True)
        link = '{0}?action=recherchevidwebglobalbtn&search=1&mode=1&pages=1'.format(_url)
        util.addMenuItem('recherche global', link, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/rech2.png', True, None, None, 'version beta')

        for video in videos:
            name =  util.extract(video, '<name>', '</name>')
            siteurl1 = urllib.quote(util.extract(video, '<loc1>', '</loc1>'))
            siteurl2 = urllib.quote(util.extract(video, '<loc2>', '</loc2>'))
            img =  util.extract(video, '<img>', '</img>')
            description =  util.extract(video, '<description>', '</description>')
            link = '{0}?action=rechdocwebbtn&nomsite={1}&urlrech={2}&urlcate={3}'.format(_url, name, siteurl1,siteurl2)
            util.addMenuItem(name, link, 'DefaultVideo.png', img, True, None, None, description)
        util.endListing()
    else:
        util.showError(ADDON_ID, 'Could not open URL %s to create menu' % (url))
        ADDON.setSetting('getnberreur', COUNTNB('{0}'.format(ADDON.getSetting( 'getnberreur'))))

def rechdocweb(nomsite, urlrech, urlcat):
    url = WEB_INDEX + 'getdecode=' + nomsite 
    response = urllib2.urlopen(url)
    if response and response.getcode() == 200:
     content = response.read()
     cdbloc1 =  util.extract(content, '<cdbloc1>', '</cdbloc1>')
     cdbloc2 =  util.extract(content, '<cdbloc2>', '</cdbloc2>')
     cdimg1 =  util.extract(content, '<cdimg1>', '</cdimg1>')
     cdimg2 =  util.extract(content, '<cdimg2>', '</cdimg2>')
     cdtitre1 =  util.extract(content, '<cdtitre1>', '</cdtitre1>')
     cdtitre2 =  util.extract(content, '<cdtitre2>', '</cdtitre2>')
     cdurl1 =  util.extract(content, '<cdurl1>', '</cdurl1>')
     cdurl2 =  util.extract(content, '<cdurl2>', '</cdurl2>')

    ### VScreateDialogOK(urldecodefix(urlcat,'1'))
     req = urllib2.Request(urldecodefix(urlcat,'1'))
     req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
     ##req.add_header('X-Requested-With', 'XMLHttpRequest')
     req.add_header('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
     req.add_header('Accept', '*/*')
     #req.add_header('Accept-Encoding', 'gzip, deflate')
     #req.add_header('Accept-Language', 'en-US,en;q=0.8,nl;q=0.6')
     #req.add_header('Connection', 'keep-alive')
     req.add_header('Accept','text/html')
     response2 = urllib2.urlopen(req)
     if response2 and response2.getcode() == 200:
      content2 = response2.read()
      datas = util.extractAll(content2, cdbloc1, cdbloc2)
      description = 'test'
      linkrech = '{0}?action=rechwebkeyboardbtn&nomsite={1}&url={2}&mode={3}&url2={4}'.format(_url, nomsite, urlrech,1,urlcat)
      linkrech2 = '{0}?action=rechwebkeyboardbtn&nomsite={1}&url={2}&mode={3}&url2={4}'.format(_url, nomsite, urlrech,2,urlcat)
      util.addMenuItem('recherche : tout', linkrech, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/rech2.png', True, None, None, description, None, None)
      util.addMenuItem('recherche : categorie', linkrech2, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/rech2.png', True, None, None, description, None, None)
      for data in datas:
            img =  util.extract(data, cdimg1, cdimg2)
            if img:
             img = img
            else:
             img =  WEB_PAGE_BASE + 'icon/none.png'

            name = util.extract(data, cdtitre1, cdtitre2)
            siturl = urllib.quote(str(util.extract(data, cdurl1, cdurl2)))

            link = '{0}?action=rechvideowebbtn&nomsite={1}&url={2}&page=1'.format(_url, nomsite, siturl)
            description = '[COLOR dimgray][B]Site : [/B][COLOR silver]'+str(nomsite)+'[/COLOR][/COLOR][CR][COLOR dimgray][B]Genre : [/B][COLOR silver]'+str(name)+'[/COLOR][/COLOR][CR]'
            if name:
             if siturl:
               util.addMenuItem(name, link, 'DefaultVideo.png', img, True, None, None,  description)
      util.endListing()


     else:
      util.showError(ADDON_ID, 'erreur decode : serveur')
 
    else:
     util.showError(ADDON_ID, 'erreur decode : serveur')
 

def urldecodefix(url,pages='1'):
 url = url.replace('/[1]/','?').replace('/[2]/','&').replace('/[3]/','=').replace('/[page]/',str(pages)).replace('/[del]/','')
 return url


def COUNTNB(COUNT2=0):
    #global COUNT
    COUNT2 = int(COUNT2) + 1
    return '{0}'.format(COUNT2)

def rechvideowebcat(nomsite, url2, urlcat):
    #-------------------------------------------------------------------

    #-------------------------------------------------------------------

    url = WEB_INDEX + 'getdecode=' + nomsite 
    response = urllib2.urlopen(url)
    if response and response.getcode() == 200:
     content = response.read()
     cdbloc1 =  util.extract(content, '<cdbloc1>', '</cdbloc1>')
     cdbloc2 =  util.extract(content, '<cdbloc2>', '</cdbloc2>')
     cdimg1 =  util.extract(content, '<cdimg1>', '</cdimg1>')
     cdimg2 =  util.extract(content, '<cdimg2>', '</cdimg2>')
     cdtitre1 =  util.extract(content, '<cdtitre1>', '</cdtitre1>')
     cdtitre2 =  util.extract(content, '<cdtitre2>', '</cdtitre2>')
     cdurl1 =  util.extract(content, '<cdurl1>', '</cdurl1>')
     cdurl2 =  util.extract(content, '<cdurl2>', '</cdurl2>')

     #VScreateDialogOK(urldecodefix(urlcat))
     req = urllib2.Request(urldecodefix(urlcat))
     req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
     ##req.add_header('X-Requested-With', 'XMLHttpRequest')
     req.add_header('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
     req.add_header('Accept', '*/*')
     #req.add_header('Accept-Encoding', 'gzip, deflate')
     #req.add_header('Accept-Language', 'en-US,en;q=0.8,nl;q=0.6')
     #req.add_header('Connection', 'keep-alive')
     req.add_header('Accept','text/html')
     response2 = urllib2.urlopen(req)
     if response2 and response2.getcode() == 200:
      content2 = response2.read()
      datas = util.extractAll(content2, cdbloc1, cdbloc2)
      description = 'test'
     # linkrech = '{0}?action=rechwebkeyboardbtn&nomsite={1}&url={2}&mode={3}'.format(_url, nomsite, urlrech,1)
      #linkrech2 = '{0}?action=rechwebkeyboardbtn&nomsite={1}&url={2}&mode={3}'.format(_url, nomsite, urlrech,2)
      #util.addMenuItem('recherche : tout', linkrech, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/rech2.png', True, None, None, description, None, None)
      #util.addMenuItem('recherche : categorie', linkrech2, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/rech2.png', True, None, None, description, None, None)
      #VScreateDialogOK(urldecodefix(url2))
      pDialog = xbmcgui.DialogProgress()
      pDialog.create('Recherche en cours ...', 'Demarrage de la recherche')
      COUNT = 1
      FINCOUNT = 0
      for data in datas:

       FINCOUNT += 1

      for data in datas:

            img =  util.extract(data, cdimg1, cdimg2)
            if img:
             img = img
            else:
             img =  WEB_PAGE_BASE + 'icon/none.png'
            name =  util.extract(data, cdtitre1, cdtitre2)
            #siturl = urllib.quote(util.extract(data, cdurl1, cdurl2))
            if name:
             #-------------------------------------------------------------------
             vidimg1 =  util.extract(content, '<vidimg1>', '</vidimg1>')
             vidimg2 =  util.extract(content, '<vidimg2>', '</vidimg2>')

             req1 = urllib2.Request(urldecodefix(url2.replace('/[icicategories]/',str(COUNT))))
             req1.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
             req1.add_header('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
             req1.add_header('Accept', '*/*')
             req1.add_header('Accept','text/html')
             #req.add_header('Cookie', 'token={0}'.format(token))
             response3 = urllib2.urlopen(req1)
             if response3 and response3.getcode() == 200:
              content3 = response3.read()

              dataok =  util.extract(content3, vidimg1, vidimg2)
              #-------------------------------------------------------------------
            COUNT += 1
            PROGCOUNT = int(float(COUNT * 100) / FINCOUNT)
            link = '{0}?action=rechvideowebbtn&nomsite={1}&url={2}&page=1'.format(_url, nomsite, url2.replace('/[icicategories]/',str(COUNT)))
            description = str(COUNT)+' [COLOR dimgray][B]Site : [/B][COLOR silver]'+str(nomsite)+'[/COLOR][/COLOR][CR][COLOR dimgray][B]Genre : [/B][COLOR silver]'+str(name)+'[/COLOR][/COLOR][CR]'
            pDialog.update( PROGCOUNT, 'Chargement : '+str(COUNT)+'/'+str(FINCOUNT)+ ' : '+str(name))

            if name:
              if dataok:
               util.addMenuItem(name, link, 'DefaultVideo.png', img, True, None, None,  description)
               del dataok
               del req1
               del content3

      util.endListing()
      pDialog.close()

     else:
      util.showError(ADDON_ID, 'erreur decode : serveur')
 
    else:
     util.showError(ADDON_ID, 'erreur decode : serveur')

def rechwebkeyboard(nomsite, url2, mode, url1):

    #pDialog = xbmcgui.DialogProgress()
    #pDialog.create('Recherche en cours ...', 'Demarrage de la recherche')
    global COUNT
    global pourcents
    keyboard = xbmc.Keyboard( '', 'Recherche '+nomsite, False )
    keyboard.doModal()
    searchstring = ' '
    if ( keyboard.isConfirmed() ):
     searchstring = keyboard.getText()
     if mode == '1':
      urlrecherhe = url2.replace('/[icirecherche]/',searchstring).replace('/[icicategories]/','').replace('//[icicategories-name]/','')
      return rechvideoweb(nomsite, urlrecherhe, 1)
     elif mode == '2':
      urlrecherhe = url2.replace('/[icirecherche]/',searchstring)
      return rechvideowebcat(nomsite, urlrecherhe, url1)



def rechvideoweb(nomsite, url2, pages='1'):
    url = WEB_INDEX + 'getdecode=' + nomsite 
    response = urllib2.urlopen(url)
    if response and response.getcode() == 200:
     content = response.read()
     vidbloc1 =  util.extract(content, '<vidbloc1>', '</vidbloc1>')
     vidbloc2 =  util.extract(content, '<vidbloc2>', '</vidbloc2>')
     vidimg1 =  util.extract(content, '<vidimg1>', '</vidimg1>')
     vidimg2 =  util.extract(content, '<vidimg2>', '</vidimg2>')
     vidtitre1 =  util.extract(content, '<vidtitre1>', '</vidtitre1>')
     vidtitre2 =  util.extract(content, '<vidtitre2>', '</vidtitre2>')
     vidurl1 =  util.extract(content, '<vidurl1>', '</vidurl1>')
     vidurl2 =  util.extract(content, '<vidurl2>', '</vidurl2>')
     vidtime1 =  util.extract(content, '<vidtime1>', '</vidtime1>')
     vidtime2 =  util.extract(content, '<vidtime2>', '</vidtime2>')
     vidhd1 =  util.extract(content, '<vidhd1>', '</vidhd1>')
     vidhd2 =  util.extract(content, '<vidhd2>', '</vidhd2>')
     vidpospagenb1 =  util.extract(content, '<vidpospagenb1>', '</vidpospagenb1>')
     vidpospagenb2 =  util.extract(content, '<vidpospagenb2>', '</vidpospagenb2>')
     #VScreateDialogOK('{0}{1}{2}'.format(urldecodefix(url2,pages).replace('https://www.porntrex.com/',''),urldecodefix(vidpospagenb1,pages),urldecodefix(vidpospagenb2,pages)))


 
     req = urllib2.Request('{0}{1}{2}'.format(urldecodefix(url2,pages),urldecodefix(vidpospagenb1,pages),urldecodefix(vidpospagenb2,pages)))
     req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
     ##req.add_header('X-Requested-With', 'XMLHttpRequest')
     req.add_header('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
     req.add_header('Accept', '*/*')
     #req.add_header('Accept-Encoding', 'gzip, deflate')
     #req.add_header('Accept-Language', 'en-US,en;q=0.8,nl;q=0.6')
     #req.add_header('Connection', 'keep-alive')
     req.add_header('Accept','text/html')
     response2 = urllib2.urlopen(req)
     if response2 and response2.getcode() == 200:
      content2 = response2.read()
      datas = util.extractAll(content2, vidbloc1, vidbloc2)
      i = 0


      for data in datas:
            time2 = None
            img =  util.extract(data, vidimg1, vidimg2)
            name =  util.extract(data, vidtitre1, vidtitre2)
            time =  util.extract(data, vidtime1, vidtime2)
            min = time.replace(':','')[:2]
            sec = time.replace(':','')[2:]

            time2 = (int(min) * 60) + int(sec)
            hd =  util.extract(data, vidhd1, vidhd2)
            if hd:
             hd = '[COLOR lime]HD[/COLOR]'
             hd0 = 'hd'
            else:
             hd = '[COLOR orange]SD[/COLOR]'
             hd0 = 'sd'
            siturl = urllib.quote(str(util.extract(data, vidurl1, vidurl2)))
            link = '{0}?action=mediaplayerbtn&nomsite={1}&url={2}&titre={3}&img={4}'.format(_url, nomsite, siturl,name,img)
            description = '[COLOR dimgray][B]Site : [/B][COLOR silver]'+str(nomsite)+'[/COLOR][/COLOR][CR][COLOR dimgray][B]Duree : [/B][COLOR silver]'+str(time)+'[/COLOR][/COLOR][CR][COLOR dimgray][B]Resolution  : [/B][COLOR silver]'+str(hd)+'[/COLOR][/COLOR][CR][COLOR dimgray][B]Titre : [/B][COLOR silver]'+str(name)+'[/COLOR][/COLOR][CR]'

            if name:
             util.addMenuItemwebvideo(name, link, 'DefaultVideo.png', img, False, str(time2), None, description, hd0, img,siturl,nomsite)            
            i += 1  
      if i >= 18:
        linkpage = '{0}?action=rechvideowebbtn&nomsite={1}&url={2}&page={3}'.format(_url, nomsite, url2, str(COUNTNB(pages)))
        util.addMenuItem('page :' + str(COUNTNB(pages)), linkpage, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/pagenext.png', True, str(time2), None, description, hd0, img)
      util.endListing()


     else:
      util.showError(ADDON_ID, 'erreur decode : serveur')
 
    else:
     util.showError(ADDON_ID, 'erreur decode : serveur')

def checurl(url='https://someURL'):
 try:
     req = urllib2.Request(url)
     req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
     ##req.add_header('X-Requested-With', 'XMLHttpRequest')
     req.add_header('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
     req.add_header('Accept', '*/*')
     #req.add_header('Accept-Encoding', 'gzip, deflate')
     #req.add_header('Accept-Language', 'en-US,en;q=0.8,nl;q=0.6')
     #req.add_header('Connection', 'keep-alive')
     req.add_header('Accept','text/html')
     urllib2.urlopen(req)
     check = '200'
 except:
    check = '404'
 return check

def rechvideoweb2(nomsite, url2, pages='1'):
    url = WEB_INDEX + 'getdecode=' + nomsite 
    response = urllib2.urlopen(url)
    if response and response.getcode() == 200:
     content = response.read()
     vidbloc1 =  util.extract(content, '<vidbloc1>', '</vidbloc1>')
     vidbloc2 =  util.extract(content, '<vidbloc2>', '</vidbloc2>')
     vidimg1 =  util.extract(content, '<vidimg1>', '</vidimg1>')
     vidimg2 =  util.extract(content, '<vidimg2>', '</vidimg2>')
     vidtitre1 =  util.extract(content, '<vidtitre1>', '</vidtitre1>')
     vidtitre2 =  util.extract(content, '<vidtitre2>', '</vidtitre2>')
     vidurl1 =  util.extract(content, '<vidurl1>', '</vidurl1>')
     vidurl2 =  util.extract(content, '<vidurl2>', '</vidurl2>')
     vidtime1 =  util.extract(content, '<vidtime1>', '</vidtime1>')
     vidtime2 =  util.extract(content, '<vidtime2>', '</vidtime2>')
     vidhd1 =  util.extract(content, '<vidhd1>', '</vidhd1>')
     vidhd2 =  util.extract(content, '<vidhd2>', '</vidhd2>')
     vidpospagenb1 =  util.extract(content, '<vidpospagenb1>', '</vidpospagenb1>')
     vidpospagenb2 =  util.extract(content, '<vidpospagenb2>', '</vidpospagenb2>')
     #VScreateDialogOK('{0}{1}{2}'.format(urldecodefix(url2,pages).replace('https://www.porntrex.com/',''),urldecodefix(vidpospagenb1,pages),urldecodefix(vidpospagenb2,pages)))


     urldata = '{0}{1}{2}'.format(urldecodefix(url2,pages),urldecodefix(vidpospagenb1,pages),urldecodefix(vidpospagenb2,pages))
     req = urllib2.Request(urldata)
     req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
     ##req.add_header('X-Requested-With', 'XMLHttpRequest')
     req.add_header('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
     req.add_header('Accept', '*/*')
     #req.add_header('Accept-Encoding', 'gzip, deflate')
     #req.add_header('Accept-Language', 'en-US,en;q=0.8,nl;q=0.6')
     #req.add_header('Connection', 'keep-alive')
     req.add_header('Accept','text/html')
     if checurl(urldata) == '200':
      response2 = urllib2.urlopen(req)
     else:
      response2 = None
     
     if response2 and response2.getcode() == 200:
      content2 = response2.read()
      datas = util.extractAll(content2, vidbloc1, vidbloc2)
      i = 0
      COUNT = 1
      FINCOUNT = 0
      for data in datas:
        FINCOUNT += 1
      pDialog = xbmcgui.DialogProgress()
      pDialog.create('Recherche en cours ...', 'Demarrage de la recherche')
      for data in datas:
            time2 = None
            img =  util.extract(data, vidimg1, vidimg2)
            name =  util.extract(data, vidtitre1, vidtitre2)
            time =  util.extract(data, vidtime1, vidtime2)
            min = time.replace(':','')[:2]
            sec = time.replace(':','')[2:]

            time2 = (int(min) * 60) + int(sec)
            hd =  util.extract(data, vidhd1, vidhd2)
            if hd:
             hd = '[COLOR lime]HD[/COLOR]'
             hd0 = 'hd'
            else:
             hd = '[COLOR orange]SD[/COLOR]'
             hd0 = 'sd'
            siturl = urllib.quote(str(util.extract(data, vidurl1, vidurl2)))
            link = '{0}?action=mediaplayerbtn&nomsite={1}&url={2}&titre={3}&img={4}'.format(_url, nomsite, siturl,name,img)
            description = '[COLOR dimgray][B]Site : [/B][COLOR silver]'+str(nomsite)+'[/COLOR][/COLOR][CR][COLOR dimgray][B]Duree : [/B][COLOR silver]'+str(time)+'[/COLOR][/COLOR][CR][COLOR dimgray][B]Resolution  : [/B][COLOR silver]'+str(hd)+'[/COLOR][/COLOR][CR][COLOR dimgray][B]Titre : [/B][COLOR silver]'+str(name)+'[/COLOR][/COLOR][CR]'

            PROGCOUNT = int(float(COUNT * 100) / FINCOUNT)
            pDialog.update( PROGCOUNT, 'Chargement : '+str(COUNT)+'/'+str(FINCOUNT)+ ' : '+str(name))
            COUNT += 1
            if name:
             util.addMenuItemwebvideo(name, link, 'DefaultVideo.png', img, False, str(time2), None, description, hd0, img, siturl,nomsite)            
            i += 1  
      if i >= 20:
        linkpage = '{0}?action=rechvideowebbtn&nomsite={1}&url={2}&page={3}'.format(_url, nomsite, url2, str(COUNTNB(pages)))
        #util.addMenuItem('page :' + str(COUNTNB(pages)), linkpage, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/pagenext.png', True, str(time2), None, description, hd0, img)



     else:
      #util.showError(ADDON_ID, '0erreur decode : serveur')
      print('aucun r�sultat sur:' +nomsite)
 
    else:
     util.showError(ADDON_ID, 'erreur decode : serveur')

def mediaplayer(nomsite,url2,titre,img):
    url = WEB_INDEX + 'getdecode=' + nomsite 
    response = urllib2.urlopen(url)
    if response and response.getcode() == 200:
     content = response.read()
     fluxsd1 =  util.extract(content, '<fluxsd1>', '</fluxsd1>')
     fluxsd2 =  util.extract(content, '<fluxsd2>', '</fluxsd2>')
     fluxhd1 =  util.extract(content, '<fluxhd1>', '</fluxhd1>')
     fluxhd2 =  util.extract(content, '<fluxhd2>', '</fluxhd2>')
     fluxinfo =  util.extract(content, '<fluxinfo>', '</fluxinfo>')
     #VScreateDialogOK(urlcat)
     req = urllib2.Request(url2)
     req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
     ##req.add_header('X-Requested-With', 'XMLHttpRequest')
     req.add_header('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
     req.add_header('Accept', '*/*')
     #req.add_header('Accept-Encoding', 'gzip, deflate')
     #req.add_header('Accept-Language', 'en-US,en;q=0.8,nl;q=0.6')
     #req.add_header('Connection', 'keep-alive')
     req.add_header('Accept','text/html')
     response2 = urllib2.urlopen(req)
     if response2 and response2.getcode() == 200:
      content2 = response2.read()
  
      fluxsd =  util.extract(content2, fluxsd1, fluxsd2)
      fluxhd =  util.extract(content2, fluxhd1, fluxhd2)
      if fluxhd:
          util.notify(ADDON_ID, '[COLOR lime]HD[/COLOR] '+fluxinfo ,5000 ,img)
          util.playMedia(titre, img, fluxhd.replace('\/','/').replace("pornfun.com","https://pornfun.com"), 'Video')
          ADDON.setSetting('getnbvideo', COUNTNB('{0}'.format(ADDON.getSetting( 'getnbvideo'))))
      else:

          util.notify(ADDON_ID, '[COLOR orange]SD[/COLOR] '+fluxinfo ,5000 ,img)
          util.playMedia(titre, img, fluxsd.replace('\/','/').replace("pornfun.com","https://pornfun.com"), 'Video')
          ADDON.setSetting('getnbvideo', COUNTNB('{0}'.format(ADDON.getSetting( 'getnbvideo'))))

     else:
      util.showError(ADDON_ID, 'erreur decode : serveur')
 
    else:
     util.showError(ADDON_ID, 'erreur decode : serveur')

