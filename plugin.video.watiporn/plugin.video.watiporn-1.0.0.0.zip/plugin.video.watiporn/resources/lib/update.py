import urllib
import urllib2
import json
import os.path
import re
import tarfile
from sets import Set
import xbmcgui
import xbmc
import xbmcaddon
import os
import sys
import time
import zipfile
nameaddons = "plugin.video.watiporn"
__addon__       = xbmcaddon.Addon(id="{0}".format(nameaddons))
__addonname__   = __addon__.getAddonInfo('name')
__language__   = __addon__.getLocalizedString
__cwd__        = __addon__.getAddonInfo('path')
notificationTime = 4000


def log(msg):
	xbmc.log('Update::' + msg)

def showNotification(msg):
	'''
	display a GUI notification
	'''
	log(msg)
	xbmc.executebuiltin('Notification(%s,%s,%d)' % (__addonname__, msg, notificationTime))
	
def extractup(text, startText, endText):
    """
    Extract the first occurence of a string within text that start with startText and end with endText
    
    Parameters:
    text: the text to be parsed
    startText: the starting tokem
    endText: the ending token
    
    Returns the string found between startText and endText, or None if the startText or endText is not found
    """
    start = text.find(startText, 0)
    if start != -1:
        start = start + startText.__len__()
        end = text.find(endText, start + 1)
        if end != -1:
            return text[start:end]
    return None

def extractAllup(text, startText, endText):
    """
    Extract all occurences of a string within text that start with startText and end with endText
    
    Parameters:
    text: the text to be parsed
    startText: the starting tokem
    endText: the ending token
    
    Returns an array containing all occurences found, with tabs and newlines removed and leading whitespace removed
    """
    result = []
    start = 0
    pos = text.find(startText, start)
    while pos != -1:
        start = pos + startText.__len__()
        end = text.find(endText, start)
        result.append(text[start:end].replace('\n', '').replace('\r', '').replace('  ', '').replace('\t', '').lstrip())
        pos = text.find(startText, end)
    return result


videoDir = __addon__.getSetting("videoDir")

           


    
version = __addon__.getAddonInfo('version')    

showNotification(__cwd__)
percent = 0
def DownloaderClass(url,dest,vers):
    dp = xbmcgui.DialogProgress()
    dp.create("Mise a jour","Telechargement de la mise a jour "+str(__addonname__)+str(vers),url)
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except: 
        percent = 100
        dp.update(percent)
        time.sleep(20)
        dp.close()
    if dp.iscanceled(): 
        dp.close()

        
#DownloaderClass(url,'special://home/test.zip')
xbmc.log("info: {0}".format(version), xbmc.LOGERROR)
xbmc.log("info: {0}".format(__cwd__), xbmc.LOGERROR)
xbmc.log("info: {0}".format(__addon__), xbmc.LOGERROR)
xbmc.log("info: {0}".format(__addonname__), xbmc.LOGERROR) 

def checkupdate(url):
 req = urllib2.Request(url)
 req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
 req.add_header('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
 req.add_header('Accept', '*/*')
 req.add_header('Accept','text/html')
 u = urllib2.urlopen(req)
 if u and u.getcode() == 200:
        content = u.read()
        content = extractAllup(content, '</td><td><a href="', '</td>')
        for contents in content:
         idversion = extractup(contents, 'zip">'+nameaddons+'-', '.zip</a>')
         if idversion:
           idversion = idversion.replace('.','')
           idversion2 = version.replace('.','')
           if idversion2 < idversion:
            versionActuel = version
            versionnew = extractup(contents, 'zip">'+nameaddons+'-', '.zip</a>')
            fileupdate = url + nameaddons+'-'+ versionnew +'.zip'
        if fileupdate:
         showNotification("Mise a jours "+versionnew)

         xbmc.log("{0}".format(xbmc.translatePath('special://home/addons/temp/'))+nameaddons+"-"+versionnew+'.zip', xbmc.LOGERROR)
         DownloaderClass(fileupdate,"{0}".format(xbmc.translatePath('special://home/addons/temp/'))+nameaddons+"-"+versionnew+'.zip',versionnew)
         installupdate("{0}".format(xbmc.translatePath('special://home/addons/temp/'))+nameaddons+"-"+versionnew+'.zip',"{0}".format(xbmc.translatePath('special://home/addons')))
 else:
  showNotification("error")

def installupdate(targetzip,extract):
        dp = xbmcgui.DialogProgress()

        zin = zipfile.ZipFile(targetzip, 'r')
#        Unzip File To HOME As Defined At Top
        zin.extractall(extract)
        dp.create('Installing update')
#          Update Addon
        xbmc.executebuiltin("UpdateLocalAddons")
#          Refresh Addon Repo
        xbmc.executebuiltin("UpdateAddonRepos")
#      Change Progress To 100%

        dp.close()
	
checkupdate("http://api.watiporn.com/xmbc/api/plugin.video.watiporn/update/")
