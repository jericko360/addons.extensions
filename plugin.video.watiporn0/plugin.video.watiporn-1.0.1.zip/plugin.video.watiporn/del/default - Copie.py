# -*- coding: utf-8 -*-
import sys
from urlparse import parse_qsl
import xbmcgui
import xbmcplugin
import urllib2
import urllib
import xbmc, xbmcaddon
import util
import htmlentitydefs
import unicodedata
import math
import time
reload(sys)
sys.setdefaultencoding("utf-8")
COUNT = 0
barpro = 0
tempprog = 0#0.01
ADDON        = xbmcaddon.Addon()
_url = sys.argv[0]
global token
global url


def codex(video ,title ,img):
    response = urllib2.urlopen(video)
    if response and response.getcode() == 200:
        content = response.read()
        code1 = util.extract(content, '<code1>', '</code1>')
        #VScreateDialogOK(code1)
        code2 = util.extract(content, '<code2>', '</code2>')
        #VScreateDialogOK(code2)
        video1 = util.extract(content, '<server1>', '</server1>')
        #VScreateDialogOK(video1)
        video2 = util.extract(content, '<server2>', '</server2>')
        #VScreateDialogOK(video2)
        check = util.extract(content, '<check>', '</check>')
        #VScreateDialogOK(check)
        info = util.extract(content, '<info>', '</info>')

        if check == '1':
          response = urllib2.urlopen(video1)
          content = response.read()
          loc = util.extract(content, code1, code2)
          util.notify(ADDON_ID, info ,5000 ,img)

          util.playMedia(title, img, loc, 'Video') 
        else:

         util.notify(ADDON_ID, info ,5000 ,img)
         util.playMedia(title, img, video2, 'Video')

    else:
        util.showError(ADDON_ID, 'Could not open URL %s to get video information' % (video))
 


def playVideo(video ,title ,img):
    response = urllib2.urlopen(video)
    if response and response.getcode() == 200:
        content = response.read()
        VScreateDialogOK('test'+video)
        videoLink = util.extract(content, '<flux>', '</flux>')
        util.playMedia(title, img, videoLink, 'Video')
    else:
        util.showError(ADDON_ID, 'Could not open URL %s to get video information' % (video))
    
def video():
    global COUNT
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Synchronisation watiporn', 'Connections en cours')
    url = WEB_INDEX + 'view=ok'+ xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')
    rechurl = '{0}?action=rech&video={1}&title={2}&image={3}'.format(_url, WEB_INDEX + 'rech=dp', 'recherche', 'http://watiporn.com/media/categories/video/1.jpg')
    response = urllib2.urlopen(url)
    if response and response.getcode() == 200:
        content = response.read()
        videos = util.extractAll(content, '<cate>', '</cate>')
        util.addMenuItem('( [B]Recherche[/B] )', rechurl, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/rech.png', True)
        for video in videos:
            info =  util.extract(video, '<pourcents>', '</pourcents>')
           
            if COUNT < 100:
             COUNT += 1
             time.sleep(tempprog)
            pDialog.update( COUNT, info)
            videourl = WEB_PAGE_BASE + util.extract(video, '<loc>', '</loc>')
            img =  util.extract(video, '<img>', '</img>')
            title =  util.extract(video, '<title>', '</title>')
            link = '{0}?action=cat&categorie={4}&video={1}&title={2}&image={3}'.format(_url, videourl, title, img, COUNT)
            util.addMenuItem(title, link, 'DefaultVideo.png', img, True)
        util.endListing()
    else:
        util.showError(ADDON_ID, 'Could not open URL %s to create menu' % (url))
        
def recherche():
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Recherche en cours ...', 'Demarrage de la recherche')
    global COUNT
    global pourcents
    keyboard = xbmc.Keyboard( '', 'Recherche watiporn', False )
    keyboard.doModal()
    searchstring = ' '
    if ( keyboard.isConfirmed() ):
     searchstring = keyboard.getText()
     pDialog.update( COUNT, 'Recherche watiporn :' + searchstring )
    url = WEB_INDEX + 'view=ok&viewrech=' + searchstring + urllib.quote(xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin'))
    rechurl = '{0}?action=cat&video={1}&title={2}&image={3}'.format(_url, WEB_INDEX + 'rech={1}{2}'.format('all', searchstring, urllib.quote(xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin'))), 'recherche', 'http://watiporn.com/media/categories/video/1.jpg')
    response = urllib2.urlopen(url)
    if response and response.getcode() == 200:
        content = response.read()
        videos = util.extractAll(content, '<cate>', '</cate>')
        nb =  util.extract(content, '<nb>', '</nb>')
        #pourcents =  util.extract(content, '<pourcents>', '</pourcents>')
        #pourcents =  1.5
        util.addMenuItem('tout '+nb, rechurl, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/rech.png', True)
        for video in videos:
            info =  util.extract(video, '<pourcents>', '</pourcents>')
           
            if COUNT < 100:
             COUNT += 1
             time.sleep(tempprog)
            pDialog.update( COUNT, info)
            id =  util.extract(video, '<id>', '</id>')
            videourl = WEB_PAGE_BASE + util.extract(video, '<loc>', '</loc>')
            img =  util.extract(video, '<img>', '</img>')
            title =  util.extract(video, '<title>', '</title>')
            link = '{0}?action=cat&video={1}&title={2}&image={3}'.format(_url, videourl, title, img)
            util.addMenuItem(title, link, 'DefaultVideo.png', img, True)
        pDialog.update( COUNT, 'Terminer ')
        util.endListing()
        pDialog.close()
    else:
        util.showError(ADDON_ID, 'Could not open URL %s to create menu' % (url))

def buildMenu2(url=None, categorie=None):
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Synchronisation videos', 'Demarrage de la Synchronisation videos')
    global COUNT

    

    response = urllib2.urlopen(url)
    if response and response.getcode() == 200:
        content = response.read()
        videos = util.extractAll(content, '<video>', '</video>')
        for video in videos:
            info =  util.extract(video, '<pourcents>', '</pourcents>')
           
            if COUNT < 100:
             COUNT += 1
             time.sleep(tempprog)
            pDialog.update( COUNT, info)
            pagesmtn = util.extract(video, '<pagem>', '</pagem>')###
            pages = util.extract(video, '<page>', '</page>')###
            favoris = util.extract(video, '<favoris>', '</favoris>')###
            vid = util.extract(video, '<vid>', '</vid>')###
            hd = util.extract(video, '<hd>', '</hd>')###
            description = util.extract(video, '<description>', '</description>')###
            duration = util.extract(video, '<time>', '</time>')
            videourl = urllib.quote(WEB_PAGE_BASE + util.extract(video, '<loc>', '</loc>'))
            img =  util.extract(video, '<img>', '</img>')
            title =  str(util.extract(video, '<title>', '</title>').decode('latin-1').encode("utf-8"))

            link = '{0}?action=play&video={1}&title={2}&image={3}'.format(_url, videourl, title, img)
            util.addMenuItem(title, link, 'DefaultVideo.png', img, False, duration, vid, description, hd, img, favoris, xbmcplugin.getSetting(int(sys.argv[1]), 'login'), xbmcplugin.getSetting(int(sys.argv[1]), 'passe'))
        if pages:
         linkpage = '{0}?action=cat&categorie={3}&video={1}{2}'.format(_url, WEB_INDEX + categorie , urllib.quote('=ok&page='+pages+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')), categorie)
         util.addMenuItem('Pages : '+pages, linkpage, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/pagenext.png', True)
        util.endListing()
        pDialog.close()        

    else:
        util.showError(ADDON_ID, 'Could not open URL %s to create menu' % (url))

def favoris(login=None, passe=None,vid=None,mode=None):
  url = '{0}login={1}&pass={2}'.format(WEB_INDEX, login, passe)
  response = urllib2.urlopen(url)
  if response and response.getcode() == 200:
     content = response.read()
     log = util.extract(content, '<etat>', '</etat>')
     prenom = util.extract(content, '<prenom>', '</prenom>')
     nom = util.extract(content, '<nom>', '</nom>') 
     token = util.extract(content, '<token>', '</token>')

     if log == 'ok':
      response = urllib2.urlopen('{0}favoris={4}&vid={3}&login={1}&pass={2}'.format(WEB_INDEX, login, passe, vid, mode))
      if response and response.getcode() == 200:
       content = response.read()
       favoris = util.extract(content, '<favoris>', '</favoris>')
       icon = util.extract(content, '<icon>', '</icon>')
       if mode == 'remove':
         util.notify(ADDON_ID, '{0}'.format(favoris),5000,icon)
         xbmc.executebuiltin('Container.Refresh')
       else:
         util.notify(ADDON_ID, '{0}'.format(favoris),5000,icon)
      else:
       util.showError(ADDON_ID, 'Video invalides!')
     else:
      util.showError(ADDON_ID, 'Pseudo ou mot de passe invalides!')
  else:
     util.showError(ADDON_ID, 'Pseudo ou mot de passe invalides!')

def mlogin(login=None, passe=None, token=None, etat=None):
  if urllib.quote(xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')):
    url = '{0}{1}'.format(WEB_INDEX, xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin'))
  else:
    url = '{0}login={1}&pass={2}'.format(WEB_INDEX, login, passe)
  req = urllib2.Request(url)
#  req.add_header('Cookie', 'token={0}'.format(token))
# Customize the default User-Agent header value:
#  req.add_header('User-Agent', 'urllib-example/0.1 (Contact: . . .)')
  response = urllib2.urlopen(req)
  if response and response.getcode() == 200:
     content = response.read()
     log = util.extract(content, '<etat>', '</etat>')
     prenom = util.extract(content, '<prenom>', '</prenom>')
     nom = util.extract(content, '<nom>', '</nom>') 
     token = util.extract(content, '<token>', '</token>')
     if etat == 'deco':

       oDialog = xbmcgui.Dialog()
       qst = oDialog.yesno("watiporn", 'voulez vous vraiment vous deconnecter ?')

       if qst == 1:
        ADDON.setSetting('acceslogin', None )
        ADDON.setSetting('login', None)
        ADDON.setSetting('passe', None)
        xbmc.executebuiltin("XBMC.Container.Update({0},replace)".format(_url))
        menu2()
       #util.endListing()
     elif log == 'ok':
       #conection ok
       util.notify(ADDON_ID, 'Bienvenue : {0} {1}'.format(prenom, nom))
       linkdeco = '{0}?action=mlogin&login={1}&passe={2}&token={3}&etat={4}'.format(_url, 'null', 'null', 'null' ,'deco')
       util.addMenuItem('deconections', linkdeco, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/deco.png', True)
       menu()



     elif etat == 'login':
       # login input
       keyboard = xbmc.Keyboard( '', 'login', False )
       keyboard.doModal()
       if ( keyboard.isConfirmed() ):
        login = keyboard.getText()
        keyboard = xbmc.Keyboard( '', 'mots de passe', False )
        keyboard.doModal()
        if ( keyboard.isConfirmed() ):
         passe = keyboard.getText()

         ADDON.setSetting('acceslogin', '&login={0}&pass={1}'.format(login, passe))
         ADDON.setSetting('login', login)
         ADDON.setSetting('passe', passe)
         resourcelogin = xbmcplugin.getSetting(int(sys.argv[1]), 'login')
         resourcepass = xbmcplugin.getSetting(int(sys.argv[1]), 'passe')
         mlogin(login, passe, 'null', 'ok')
     else:
       util.showError(ADDON_ID, 'Pseudo ou mot de passe invalides!')
       menu2()

  else:
       util.showError(ADDON_ID, 'Could not open URL %s to create menu' % (url))
def menu():
       linkvideo = '{0}?action=video'.format(_url)
       linkvideotop = '{0}?action=cat&categorie=viewtop&video={1}{2}'.format(_url, WEB_INDEX + 'viewtop=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideovue = '{0}?action=cat&categorie=viewvue&video={1}{2}'.format(_url, WEB_INDEX + 'viewvue=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideobw = '{0}?action=cat&categorie=viewbw&video={1}{2}'.format(_url, WEB_INDEX + 'viewbw=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideolg = '{0}?action=cat&categorie=viewlg&video={1}{2}'.format(_url, WEB_INDEX + 'viewlg=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideohd = '{0}?action=cat&categorie=viewhd&video={1}{2}'.format(_url, WEB_INDEX + 'viewhd=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideofavorite = '{0}?action=cat&categorie=viewfavorite&video={1}{2}'.format(_url, WEB_INDEX + 'viewfavorite=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideopremium = '{0}?action=cat&categorie=viewpremium&video={1}{2}'.format(_url, WEB_INDEX + 'viewpremium=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
   
       linkphoto = '{0}?action=photo'.format(_url)

       util.addMenuItem('Videos', linkvideo, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/video.png', True)
       util.addMenuItem('Top Classement', linkvideotop, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videotop.png', True)
       util.addMenuItem('Plus vu ', linkvideovue, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videovue.png', True)
       util.addMenuItem('Vu en ce moment', linkvideobw, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videovm.png', True)
       util.addMenuItem('Plus long ', linkvideolg, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videolg.png', True)
       util.addMenuItem('Videos hd', linkvideohd, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videohd.png', True)
       util.addMenuItem('Videos favorite', linkvideofavorite, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videohd.png', True)
       util.addMenuItem('Videos premium', linkvideopremium, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videopremium.png', True)
       #util.addMenuItem('Photo', linkphoto, 'DefaultPhoto.png', WEB_PAGE_BASE + 'icon/photo.png', True)
       util.endListing() 
       
def menu2():
       linklogin = '{0}?action=mlogin&login={1}&passe={2}&token={3}&etat={4}'.format(_url, 'null', 'null', 'null' ,'login')
       util.addMenuItem('login', linklogin, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/login.png', True)


       linkvideo = '{0}?action=video'.format(_url)
       linkvideo = '{0}?action=video'.format(_url)
       linkvideotop = '{0}?action=cat&categorie=viewtop&video={1}{2}'.format(_url, WEB_INDEX + 'viewtop=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideovue = '{0}?action=cat&categorie=viewvue&video={1}{2}'.format(_url, WEB_INDEX + 'viewvue=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideobw = '{0}?action=cat&categorie=viewbw&video={1}{2}'.format(_url, WEB_INDEX + 'viewbw=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
       linkvideolg = '{0}?action=cat&categorie=viewlg&video={1}{2}'.format(_url, WEB_INDEX + 'viewlg=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
      # linkvideohd = '{0}?action=cat&categorie=viewhd&video={1}{2}'.format(_url, WEB_INDEX + 'viewhd=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
      # linkvideofavorite = '{0}?action=cat&categorie=viewfavorite&video={1}{2}'.format(_url, WEB_INDEX + 'viewfavorite=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
      # linkvideopremium = '{0}?action=cat&categorie=viewpremium&video={1}{2}'.format(_url, WEB_INDEX + 'viewpremium=ok', urllib.quote("&page=1"+xbmcplugin.getSetting(int(sys.argv[1]), 'acceslogin')))
   

   
       linkphoto = '{0}?action=photo'.format(_url)

       util.addMenuItem('Videos', linkvideo, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/video.png', True)
       util.addMenuItem('Top Classement', linkvideotop, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videotop.png', True)
       util.addMenuItem('Plus vu ', linkvideovue, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videovue.png', True)
       util.addMenuItem('Vu en ce moment', linkvideobw, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videovm.png', True)
       util.addMenuItem('Plus long ', linkvideolg, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videolg.png', True)
       #util.addMenuItem('Videos hd', linkvideohd, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videohd.png', True)
       #util.addMenuItem('Videos premium', linkvideopremium, 'DefaultVideo.png', WEB_PAGE_BASE + 'icon/videopremium.png', True)
       #util.addMenuItem('Photo', linkphoto, 'DefaultPhoto.png', WEB_PAGE_BASE + 'icon/photo.png', True)
       util.endListing()
 
WEB_INDEX = 'http://api.watiporn.com/xmbc/code.php?'
WEB_PAGE_BASE = 'http://api.watiporn.com/xmbc/'
ADDON_ID = 'plugin.video.watiporn'
params = dict(parse_qsl(sys.argv[2][1:]))
resourcelogin = xbmcplugin.getSetting(int(sys.argv[1]), 'login')
resourcepass = xbmcplugin.getSetting(int(sys.argv[1]), 'passe')

def VScreateDialogOK(label):
    oDialog = xbmcgui.Dialog()
    oDialog.ok('watiporn', label)  
    return oDialog

def refresh(run):
    xbmc.executebuiltin("XBMC.Container.Update({0},replace)".format(_url))
    xbmc.executebuiltin("XBMC.Container.Update("+run+",replace)")
    return
    
def VScreateDialogYesNo(label):
    oDialog = xbmcgui.Dialog()
    qst = oDialog.yesno("watiporn", label)
    return qst

def VScreateDialogSelect(label):
    oDialog = xbmcgui.Dialog()
    ret = oDialog.select('Select Quality', label)  
    return ret

def createDialog(sSite):
    oDialog = xbmcgui.DialogProgress()
    oDialog.create(sSite,None)
    return oDialog

def pourcentRech(value,txt):
 pDialog = xbmcgui.DialogProgress()
 pDialog.update(1, txt + str(value) + '%')
 return oDialog
      
def updateDialog(dialog,total):
    global COUNT
    COUNT += 1
    if xbmcgui.Window(10101).getProperty('search') != 'true':
        iPercent = int(float(COUNT * 100) / total)
        dialog.update(iPercent, 'Chargement: '+str(COUNT)+'/'+str(total))



if params:
     if params['action'] == 'play':
      codex(params['video'] ,params['title'] ,params['image'])
     elif params['action'] == 'cat':
      buildMenu2(params['video'],params['categorie'])
     elif params['action'] == 'rech':
      recherche()
     elif params['action'] == 'video':
      video()
     elif params['action'] == 'mlogin':
      mlogin(params['login'], params['passe'], params['token'], params['etat'])
     elif params['action'] == 'addfavoris':
      favoris(params['login'], params['passe'],params['vid'], 'add')
     elif params['action'] == 'removefavoris':
      favoris(params['login'], params['passe'],params['vid'], 'remove')
     elif params['action'] == 'refresh':
      refresh(params['run'])
else:

     if resourcelogin:
      if resourcepass:
       mlogin()
      else:
       menu2()
     else:
      menu2()
