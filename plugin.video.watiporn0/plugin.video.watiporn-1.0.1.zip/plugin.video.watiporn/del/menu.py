# -*- coding: utf-8 -*-
import sys
from urlparse import parse_qsl
import xbmcgui
import xbmcplugin
import urllib2
import urllib
import xbmc, xbmcaddon
import util
import htmlentitydefs
import unicodedata
from math import *
import time
reload(sys)
sys.setdefaultencoding("utf-8")
COUNT = 0
barpro = 0
tempprog = 0.1#0.01
ADDON        = xbmcaddon.Addon()
_url = sys.argv[0]
global params
menudatazero = 0
params = dict(parse_qsl(sys.argv[2][1:]))

def VScreateDialogOK(label):
    oDialog = xbmcgui.Dialog()
    oDialog.ok('watiporn', label)  
    return oDialog
    
def VScreateDialogYesNo(label):
    oDialog = xbmcgui.Dialog()
    qst = oDialog.yesno("watiporn", label)
    return qst

def VScreateDialogSelect(label):
    oDialog = xbmcgui.Dialog()
    ret = oDialog.select('Select Quality', label)  
    return ret

def createDialog(sSite):
    oDialog = xbmcgui.DialogProgress()
    oDialog.create(sSite,None)
    return oDialog

def pourcentRech(value,txt):
 pDialog = xbmcgui.DialogProgress()
 pDialog.update(1, txt + str(value) + '%')
 return oDialog
      
def updateDialog(dialog,total):
    global COUNT
    COUNT += 1
    if xbmcgui.Window(10101).getProperty('search') != 'true':
        iPercent = int(float(COUNT * 100) / total)
        dialog.update(iPercent, 'Chargement: '+str(COUNT)+'/'+str(total))

if params:
     if params['action'] == 'play':
      codex(params['video'] ,params['title'] ,params['image'])
     elif params['action'] == 'cat':
      buildMenu2(params['video'])


VScreateDialogOK('test')