xbmc-adult
==========

main repo for Frodo, Gotham, Helix, Isengard, Jarvis and Krypton

See https://github.com/xbmc-adult/xbmc-adult/wiki/Devel before sending pull
requests
